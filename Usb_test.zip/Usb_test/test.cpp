#include <windows.h>
#include <setupapi.h>
#include <cfgmgr32.h>
#include <devguid.h>
#include <regstr.h>
#include <tchar.h>
#include <iostream>
#include <string>
#include <vector>
#include <regex>

#pragma comment(lib, "setupapi.lib")
#pragma comment(lib, "cfgmgr32.lib")

std::string GetRegistryProperty(HDEVINFO hDevInfo, SP_DEVINFO_DATA devInfoData, DWORD property) {
    BYTE buffer[1024];
    DWORD size = 0;
    if (SetupDiGetDeviceRegistryPropertyA(hDevInfo, &devInfoData, property, NULL, buffer, sizeof(buffer), &size)) {
        return std::string((char*)buffer);
    }
    return "<Unavailable>";
}

std::string ExtractVIDPID(const std::string& hwid) {
    std::regex re(R"(VID_([0-9A-F]{4})&PID_([0-9A-F]{4}))", std::regex::icase);
    std::smatch match;
    if (std::regex_search(hwid, match, re) && match.size() == 3) {
        return "VID_" + match[1].str() + " PID_" + match[2].str();
    }
    return "<Unknown>";
}

std::string ExtractSerial(const std::string& deviceInstanceId) {
    size_t lastSlash = deviceInstanceId.find_last_of('\\');
    if (lastSlash != std::string::npos) {
        std::string serial = deviceInstanceId.substr(lastSlash + 1);
        if (serial.find('&') == std::string::npos && serial.length() > 2) {
            return serial;
        }
    }
    return "<Unavailable>";
}

int main() {
    HDEVINFO hDevInfo;
    SP_DEVINFO_DATA devInfoData;
    DWORD index = 0;

    hDevInfo = SetupDiGetClassDevs(NULL, "USB", NULL, DIGCF_PRESENT | DIGCF_ALLCLASSES);
    if (hDevInfo == INVALID_HANDLE_VALUE) {
        std::cerr << "Failed to get device list." << std::endl;
        return 1;
    }

    devInfoData.cbSize = sizeof(SP_DEVINFO_DATA);

    while (SetupDiEnumDeviceInfo(hDevInfo, index++, &devInfoData)) {
        char deviceInstanceId[MAX_DEVICE_ID_LEN];
        if (CM_Get_Device_IDA(devInfoData.DevInst, deviceInstanceId, MAX_DEVICE_ID_LEN, 0) != CR_SUCCESS)
            continue;

        std::string hardwareId = GetRegistryProperty(hDevInfo, devInfoData, SPDRP_HARDWAREID);
        std::string manufacturer = GetRegistryProperty(hDevInfo, devInfoData, SPDRP_MFG);
        std::string description = GetRegistryProperty(hDevInfo, devInfoData, SPDRP_DEVICEDESC);
        std::string vidpid = ExtractVIDPID(hardwareId);
        std::string serial = ExtractSerial(deviceInstanceId);

        std::cout << "----------------------------------------" << std::endl;
        std::cout << "Description : " << description << std::endl;
        std::cout << "Manufacturer: " << manufacturer << std::endl;
        std::cout << "HWID        : " << hardwareId << std::endl;
        std::cout << "VID/PID     : " << vidpid << std::endl;
        std::cout << "Serial No.  : " << serial << std::endl;
    }

    SetupDiDestroyDeviceInfoList(hDevInfo);
    return 0;
}
