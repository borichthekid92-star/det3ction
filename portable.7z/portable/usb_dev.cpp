#include <libusb-1.0/libusb.h>
#include <iostream>
#include <iomanip>
#include <vector>

void printDeviceInfo(libusb_device *device) {
    libusb_device_descriptor desc;
    if (libusb_get_device_descriptor(device, &desc) != 0) {
        std::cerr << "Failed to get device descriptor" << std::endl;
        return;
    }

    libusb_device_handle *handle = nullptr;
    if (libusb_open(device, &handle) != 0) {
        std::cerr << "Unable to open device (may require driver like WinUSB or libusbK)" << std::endl;
        return;
    }

    unsigned char string[256];
    std::string manufacturer = "<Unavailable>";
    std::string product = "<Unavailable>";
    std::string serial = "<Unavailable>";

    if (desc.iManufacturer && libusb_get_string_descriptor_ascii(handle, desc.iManufacturer, string, sizeof(string)) > 0)
        manufacturer = reinterpret_cast<char*>(string);
    if (desc.iProduct && libusb_get_string_descriptor_ascii(handle, desc.iProduct, string, sizeof(string)) > 0)
        product = reinterpret_cast<char*>(string);
    if (desc.iSerialNumber && libusb_get_string_descriptor_ascii(handle, desc.iSerialNumber, string, sizeof(string)) > 0)
        serial = reinterpret_cast<char*>(string);

    std::cout << "----------------------------------------" << std::endl;
    std::cout << "Vendor ID  : 0x" << std::hex << std::setw(4) << std::setfill('0') << desc.idVendor << std::endl;
    std::cout << "Product ID : 0x" << std::hex << std::setw(4) << std::setfill('0') << desc.idProduct << std::endl;
    std::cout << "Manufacturer: " << manufacturer << std::endl;
    std::cout << "Product     : " << product << std::endl;
    std::cout << "Serial Num  : " << serial << std::endl;

    libusb_close(handle);
}

int main() {
    libusb_context *ctx = nullptr;
    libusb_device **devices = nullptr;
    ssize_t count = 0;

    if (libusb_init(&ctx) < 0) {
        std::cerr << "Failed to initialize libusb" << std::endl;
        return 1;
    }

    count = libusb_get_device_list(ctx, &devices);
    if (count < 0) {
        std::cerr << "Error getting device list" << std::endl;
        libusb_exit(ctx);
        return 1;
    }

    for (ssize_t i = 0; i < count; ++i) {
        printDeviceInfo(devices[i]);
    }

    libusb_free_device_list(devices, 1);
    libusb_exit(ctx);
    return 0;
}
