#!/bin/bash
# Quick start script for Logon F0cus Dashboard

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo "=========================================="
echo "Logon F0cus Dashboard"
echo "=========================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "[!] Please run as root to access authentication logs"
    echo "[!] Usage: sudo $0"
    exit 1
fi

# Check for test mode
if [ "$1" == "--test" ]; then
    echo "[*] Starting in TEST mode with sample data..."
    echo "[*] Using $SCRIPT_DIR/data/test_auth.log"
    echo ""
    python3 "$SCRIPT_DIR/logon_dashboard.py" -l "$SCRIPT_DIR/data/test_auth.log" --no-monitor
else
    echo "[*] Starting dashboard with real-time monitoring..."
    echo "[*] Monitoring: /var/log/auth.log"
    echo ""
    echo "[+] Dashboard will be available at:"
    echo "    http://localhost:5000"
    echo "    http://$(hostname -I | awk '{print $1}'):5000"
    echo ""
    echo "[*] Press Ctrl+C to stop"
    echo ""
    python3 "$SCRIPT_DIR/logon_dashboard.py"
fi
