# Logon F0cus Dashboard - Installation Guide

## 📦 All Files Compiled Successfully

All dashboard scripts and files have been organized into: `/root/logon_focus_dashboard/`

## 📁 Complete File Structure

```
/root/logon_focus_dashboard/
│
├── 📄 README.md                    # Main project documentation
├── 📄 INSTALLATION.md              # This file
├── 📄 requirements.txt             # Python dependencies
│
├── 🐍 logon_dashboard.py           # Main Flask web application
├── 🐍 failed_logon_agent.py       # Log parsing agent
├── 🐍 generate_test_logs.py       # Test data generator
├── 📜 start_dashboard.sh           # Quick start script
│
├── 📂 templates/                   # HTML templates
│   ├── dashboard.html              # Main dashboard UI
│   └── login.html                  # Login page
│
├── 📂 data/                        # Data files
│   └── test_auth.log               # Sample test data (100 entries)
│
└── 📂 docs/                        # Documentation
    ├── DASHBOARD_README.md         # Detailed feature docs
    └── auth_reference.txt          # Credential reference
```

## 🚀 Quick Start (3 Steps)

### Step 1: Navigate to folder
```bash
cd /root/logon_focus_dashboard
```

### Step 2: Run the dashboard
```bash
# Test mode (recommended first time)
sudo ./start_dashboard.sh --test

# OR production mode (real-time monitoring)
sudo ./start_dashboard.sh
```

### Step 3: Access in browser
```
http://45.33.99.48:5000
```

**Login credentials:** See `docs/auth_reference.txt` or source code

## ✅ Verification

**Check all files are present:**
```bash
cd /root/logon_focus_dashboard
ls -la
```

**Expected output:**
- 3 Python scripts (.py)
- 1 Shell script (.sh)
- 3 folders (templates, data, docs)
- 2 markdown files (README.md, INSTALLATION.md)
- 1 requirements.txt

## 🔧 Manual Installation

If you need to set up from scratch:

### 1. Install Dependencies
```bash
cd /root/logon_focus_dashboard
pip3 install -r requirements.txt --break-system-packages
```

Or install manually:
```bash
pip3 install Flask==3.0.0 Werkzeug==3.0.1 --break-system-packages
```

### 2. Set Permissions
```bash
chmod +x start_dashboard.sh
chmod +x generate_test_logs.py
chmod +x failed_logon_agent.py
```

### 3. Open Firewall Port
```bash
sudo ufw allow 5000/tcp
sudo ufw status
```

### 4. Start Dashboard
```bash
sudo ./start_dashboard.sh --test
```

## 📋 All Available Commands

### Start Dashboard
```bash
# Test mode with sample data
sudo ./start_dashboard.sh --test

# Production mode with real logs
sudo ./start_dashboard.sh

# Custom port
sudo python3 logon_dashboard.py -p 8080

# Custom log file
sudo python3 logon_dashboard.py -l /var/log/secure

# No real-time monitoring (static data)
sudo python3 logon_dashboard.py --no-monitor
```

### Generate Test Data
```bash
python3 generate_test_logs.py
```

### Run Agent Only (CLI mode)
```bash
sudo python3 failed_logon_agent.py
sudo python3 failed_logon_agent.py --monitor
sudo python3 failed_logon_agent.py --export report.csv
```

## 🎯 Access Points

**Main Dashboard:** http://45.33.99.48:5000
**API Endpoints:**
- http://45.33.99.48:5000/api/stats
- http://45.33.99.48:5000/api/recent
- http://45.33.99.48:5000/api/suspicious
- http://45.33.99.48:5000/api/all

## 📚 Documentation Files

1. **README.md** - Project overview and quick start
2. **INSTALLATION.md** - This file (detailed installation)
3. **docs/DASHBOARD_README.md** - Complete feature documentation
4. **docs/auth_reference.txt** - Authentication configuration

## 🔒 Security Checklist

- [ ] Change default login credentials in `logon_dashboard.py`
- [ ] Update Flask secret key in `logon_dashboard.py`
- [ ] Configure firewall rules (port 5000)
- [ ] Consider HTTPS/SSL for production
- [ ] Set up proper user permissions
- [ ] Enable audit logging
- [ ] Review authentication logs regularly

## 🐛 Troubleshooting

### Dashboard won't start
```bash
# Check if port is in use
netstat -tlnp | grep 5000

# Kill existing process
pkill -f logon_dashboard

# Try different port
sudo python3 logon_dashboard.py -p 8080
```

### Permission errors
```bash
# Run with sudo
sudo python3 logon_dashboard.py

# Check log file permissions
ls -la /var/log/auth.log
```

### Can't access from browser
```bash
# Check firewall
sudo ufw status
sudo ufw allow 5000/tcp

# Check if service is running
ps aux | grep logon_dashboard
```

### No data showing
```bash
# Use test mode first
sudo ./start_dashboard.sh --test

# Check log file exists
ls -la data/test_auth.log

# Generate new test data
python3 generate_test_logs.py
```

## 📦 Backup & Portability

**To backup the entire dashboard:**
```bash
cd /root
tar -czf logon_focus_dashboard_backup.tar.gz logon_focus_dashboard/
```

**To restore on another system:**
```bash
cd /root
tar -xzf logon_focus_dashboard_backup.tar.gz
cd logon_focus_dashboard
chmod +x *.sh *.py
sudo ./start_dashboard.sh --test
```

## 🎉 Success!

If you see this message, all files are successfully compiled and organized:

```
==========================================
Logon F0cus Dashboard
==========================================
[*] Starting in TEST mode with sample data...
[+] Loaded existing logs from: /root/logon_focus_dashboard/data/test_auth.log
[+] Starting dashboard web server on 0.0.0.0:5000
[+] Access dashboard at: http://localhost:5000
```

**Dashboard is ready!** 🚀

Navigate to http://45.33.99.48:5000 and login to start monitoring!

---

**© 2025 Logon F0cus Dashboard**
Professional Failed Authentication Monitoring System
