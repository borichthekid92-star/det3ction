#!/usr/bin/env python3
"""
Failed Logon Dashboard - Flask Web Application
Real-time dashboard for monitoring failed authentication attempts
"""

from flask import Flask, render_template, jsonify, request, session, redirect, url_for
from functools import wraps
import os
import sys
import json
from datetime import datetime
from collections import defaultdict
import threading
import time

# Import our agent
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from failed_logon_agent import FailedLogonAgent

app = Flask(__name__)
app.config['SECRET_KEY'] = 'soc-dashboard-secret-key-change-in-production-2025'

# Authentication credentials
# SECURITY WARNING: Change these default credentials in production!
CREDENTIALS = {
    'username': 'admin',
    'password': 'mikey455'
}

# Global data store
dashboard_data = {
    'failed_attempts': [],
    'stats': {},
    'last_update': None,
    'monitoring': False
}

# Lock for thread-safe operations
data_lock = threading.Lock()

# Agent instance
agent = None


def login_required(f):
    """Decorator to require login for routes"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def update_dashboard_data():
    """Update dashboard data from agent"""
    global agent, dashboard_data

    with data_lock:
        if agent and agent.failed_attempts:
            dashboard_data['failed_attempts'] = agent.failed_attempts.copy()
            dashboard_data['last_update'] = datetime.now().isoformat()

            # Calculate statistics
            type_stats = defaultdict(int)
            user_stats = defaultdict(int)
            ip_stats = defaultdict(int)

            for attempt in agent.failed_attempts:
                type_stats[attempt['type']] += 1
                user_stats[attempt['user']] += 1
                if attempt['source'] != 'Unknown':
                    ip_stats[attempt['source']] += 1

            dashboard_data['stats'] = {
                'total_attempts': len(agent.failed_attempts),
                'types': dict(type_stats),
                'top_users': dict(sorted(user_stats.items(), key=lambda x: x[1], reverse=True)[:10]),
                'top_ips': dict(sorted(ip_stats.items(), key=lambda x: x[1], reverse=True)[:10]),
                'unique_users': len(user_stats),
                'unique_ips': len(ip_stats)
            }


def monitor_logs_background(log_file):
    """Background thread to monitor logs"""
    global agent, dashboard_data

    agent = FailedLogonAgent(log_file=log_file)

    try:
        with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
            # Read existing logs first
            for line in f:
                agent._parse_line(line)

            update_dashboard_data()

            # Now follow in real-time
            dashboard_data['monitoring'] = True
            while dashboard_data['monitoring']:
                line = f.readline()
                if not line:
                    time.sleep(0.5)
                    continue

                agent._parse_line(line)
                update_dashboard_data()

    except Exception as e:
        print(f"[!] Error in monitoring thread: {e}")
        dashboard_data['monitoring'] = False


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page and authentication"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if username == CREDENTIALS['username'] and password == CREDENTIALS['password']:
            session['logged_in'] = True
            session['username'] = username
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error='Invalid username or password')

    return render_template('login.html')


@app.route('/logout')
def logout():
    """Logout and clear session"""
    session.clear()
    return redirect(url_for('login'))


@app.route('/')
@login_required
def index():
    """Main dashboard page"""
    return render_template('dashboard.html', username=session.get('username'))


@app.route('/api/stats')
@login_required
def get_stats():
    """API endpoint for statistics"""
    with data_lock:
        return jsonify(dashboard_data['stats'])


@app.route('/api/recent')
@login_required
def get_recent():
    """API endpoint for recent attempts"""
    limit = request.args.get('limit', 20, type=int)
    with data_lock:
        recent = dashboard_data['failed_attempts'][-limit:]
        return jsonify({
            'attempts': recent,
            'last_update': dashboard_data['last_update']
        })


@app.route('/api/all')
@login_required
def get_all():
    """API endpoint for all attempts"""
    with data_lock:
        return jsonify({
            'attempts': dashboard_data['failed_attempts'],
            'stats': dashboard_data['stats'],
            'last_update': dashboard_data['last_update'],
            'monitoring': dashboard_data['monitoring']
        })


@app.route('/api/suspicious')
@login_required
def get_suspicious():
    """API endpoint for suspicious activity detection"""
    with data_lock:
        alerts = []

        if not dashboard_data['stats']:
            return jsonify({'alerts': []})

        top_ips = dashboard_data['stats'].get('top_ips', {})
        top_users = dashboard_data['stats'].get('top_users', {})

        # High attempt count from single IP
        for ip, count in top_ips.items():
            if count > 10:
                alerts.append({
                    'severity': 'high' if count > 50 else 'medium',
                    'type': 'Brute Force',
                    'message': f'High attempt count from IP {ip}: {count} attempts',
                    'details': {'ip': ip, 'count': count}
                })

        # Attacks on sensitive accounts
        sensitive_users = ['root', 'admin', 'administrator', 'postgres', 'mysql']
        for user in sensitive_users:
            if user in top_users:
                alerts.append({
                    'severity': 'critical',
                    'type': 'Sensitive Account',
                    'message': f'Failed attempts on sensitive account "{user}": {top_users[user]} attempts',
                    'details': {'user': user, 'count': top_users[user]}
                })

        # Distributed attacks
        for user, count in top_users.items():
            if count > 20:
                ips_targeting = set(a['source'] for a in dashboard_data['failed_attempts'] if a['user'] == user)
                if len(ips_targeting) > 5:
                    alerts.append({
                        'severity': 'high',
                        'type': 'Distributed Attack',
                        'message': f'Distributed attack on user "{user}": {count} attempts from {len(ips_targeting)} IPs',
                        'details': {'user': user, 'count': count, 'ip_count': len(ips_targeting)}
                    })

        return jsonify({'alerts': alerts})


@app.route('/api/timeline')
@login_required
def get_timeline():
    """API endpoint for timeline data"""
    with data_lock:
        # Group attempts by hour for timeline visualization
        timeline = defaultdict(int)

        for attempt in dashboard_data['failed_attempts']:
            # Extract hour from timestamp (format: "Oct 28 16:26:15")
            try:
                ts = attempt['timestamp']
                # Simple grouping by timestamp string
                timeline[ts[:10]] += 1  # Group by date/hour
            except:
                pass

        return jsonify({
            'timeline': dict(timeline)
        })


def main():
    """Main entry point"""
    import argparse

    parser = argparse.ArgumentParser(description='Failed Logon Dashboard - Web Interface')
    parser.add_argument('-p', '--port', type=int, default=5000,
                        help='Port to run the web server on (default: 5000)')
    parser.add_argument('--host', default='0.0.0.0',
                        help='Host to bind to (default: 0.0.0.0)')
    parser.add_argument('-l', '--log', default='/var/log/auth.log',
                        help='Path to authentication log file (default: /var/log/auth.log)')
    parser.add_argument('--no-monitor', action='store_true',
                        help='Disable real-time monitoring (only show existing logs)')

    args = parser.parse_args()

    # Check for log file
    log_file = args.log
    if not os.path.exists(log_file):
        alt_logs = ['/var/log/auth.log', '/var/log/secure', '/var/log/messages']
        for alt in alt_logs:
            if os.path.exists(alt):
                log_file = alt
                break

    # Start monitoring thread
    if not args.no_monitor:
        monitor_thread = threading.Thread(target=monitor_logs_background, args=(log_file,), daemon=True)
        monitor_thread.start()
        print(f"[+] Started background log monitoring: {log_file}")
    else:
        # Just load existing logs once
        global agent
        agent = FailedLogonAgent(log_file=log_file)
        agent.parse_log_file(follow=False)
        update_dashboard_data()
        print(f"[+] Loaded existing logs from: {log_file}")

    print(f"[+] Starting dashboard web server on {args.host}:{args.port}")
    print(f"[+] Access dashboard at: http://{args.host if args.host != '0.0.0.0' else 'localhost'}:{args.port}")
    print(f"[!] Authentication required - Login page enabled")
    print(f"[!] SECURITY: Remember to change default credentials in production!")

    app.run(host=args.host, port=args.port, debug=False, threaded=True)


if __name__ == '__main__':
    main()
