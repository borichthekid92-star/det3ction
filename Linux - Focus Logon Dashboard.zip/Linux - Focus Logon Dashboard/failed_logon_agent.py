#!/usr/bin/env python3
"""
Failed Logon Monitoring Agent
Monitors and reports failed authentication attempts from system logs
"""

import re
import os
import sys
import time
from datetime import datetime
from collections import defaultdict
import argparse


class FailedLogonAgent:
    """Agent for monitoring and analyzing failed logon attempts"""

    def __init__(self, log_file="/var/log/auth.log", monitor_mode=False):
        self.log_file = log_file
        self.monitor_mode = monitor_mode
        self.failed_attempts = []
        self.stats = defaultdict(int)

        # Common failed authentication patterns
        self.patterns = [
            # SSH failed password
            (r'(\w+\s+\d+\s+\d+:\d+:\d+).*sshd.*Failed password for (?:invalid user )?(\S+) from (\S+) port (\d+)',
             'SSH Failed Password'),
            # SSH invalid user
            (r'(\w+\s+\d+\s+\d+:\d+:\d+).*sshd.*Invalid user (\S+) from (\S+) port (\d+)',
             'SSH Invalid User'),
            # SSH disconnected (auth fail)
            (r'(\w+\s+\d+\s+\d+:\d+:\d+).*sshd.*Disconnected from invalid user (\S+) (\S+) port (\d+)',
             'SSH Disconnected'),
            # PAM authentication failure
            (r'(\w+\s+\d+\s+\d+:\d+:\d+).*pam.*authentication failure.*user=(\S+)',
             'PAM Auth Failure'),
            # sudo failed attempts
            (r'(\w+\s+\d+\s+\d+:\d+:\d+).*sudo.*(\S+) : .* ; USER=\S+ ; COMMAND=.*',
             'Sudo Failed'),
            # Failed su attempts
            (r'(\w+\s+\d+\s+\d+:\d+:\d+).*su.*FAILED su for (\S+) by (\S+)',
             'SU Failed'),
        ]

    def parse_log_file(self, follow=False):
        """Parse the authentication log file"""
        try:
            if not os.path.exists(self.log_file):
                # Try alternative log locations
                alt_logs = [
                    "/var/log/auth.log",
                    "/var/log/secure",
                    "/var/log/messages"
                ]
                for alt_log in alt_logs:
                    if os.path.exists(alt_log):
                        self.log_file = alt_log
                        break
                else:
                    print(f"[!] No authentication log found. Tried: {', '.join(alt_logs)}")
                    return

            if follow:
                self._follow_log()
            else:
                with open(self.log_file, 'r', encoding='utf-8', errors='ignore') as f:
                    for line in f:
                        self._parse_line(line)
        except PermissionError:
            print(f"[!] Permission denied reading {self.log_file}")
            print("[!] Try running with sudo: sudo python3 failed_logon_agent.py")
            sys.exit(1)
        except Exception as e:
            print(f"[!] Error reading log file: {e}")
            sys.exit(1)

    def _follow_log(self):
        """Follow log file in real-time (like tail -f)"""
        print(f"[*] Monitoring {self.log_file} in real-time... (Ctrl+C to stop)\n")

        with open(self.log_file, 'r', encoding='utf-8', errors='ignore') as f:
            # Go to end of file
            f.seek(0, 2)

            try:
                while True:
                    line = f.readline()
                    if not line:
                        time.sleep(0.1)
                        continue
                    self._parse_line(line, live=True)
            except KeyboardInterrupt:
                print("\n[*] Monitoring stopped")

    def _parse_line(self, line, live=False):
        """Parse a single log line for failed authentication attempts"""
        for pattern, failure_type in self.patterns:
            match = re.search(pattern, line)
            if match:
                groups = match.groups()
                timestamp = groups[0] if len(groups) > 0 else "Unknown"
                user = groups[1] if len(groups) > 1 else "Unknown"
                source_ip = groups[2] if len(groups) > 2 else "Unknown"

                attempt = {
                    'timestamp': timestamp,
                    'type': failure_type,
                    'user': user,
                    'source': source_ip,
                    'raw': line.strip()
                }

                self.failed_attempts.append(attempt)
                self.stats[failure_type] += 1
                self.stats[f"user_{user}"] += 1
                self.stats[f"ip_{source_ip}"] += 1

                if live:
                    self._print_attempt(attempt)

                break

    def _print_attempt(self, attempt):
        """Print a single failed attempt"""
        print(f"[{attempt['timestamp']}] {attempt['type']:20s} | User: {attempt['user']:15s} | From: {attempt['source']}")

    def generate_report(self):
        """Generate a comprehensive report of failed logon attempts"""
        if not self.failed_attempts:
            print("[*] No failed logon attempts found in the log file.")
            return

        print("=" * 100)
        print(f"FAILED LOGON ATTEMPTS REPORT - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Log File: {self.log_file}")
        print("=" * 100)
        print()

        # Summary statistics
        print(f"[+] Total Failed Attempts: {len(self.failed_attempts)}")
        print()

        # Failure type breakdown
        print("[+] Failure Types:")
        type_stats = {}
        for attempt in self.failed_attempts:
            type_stats[attempt['type']] = type_stats.get(attempt['type'], 0) + 1

        for failure_type, count in sorted(type_stats.items(), key=lambda x: x[1], reverse=True):
            print(f"    {failure_type:25s}: {count:5d}")
        print()

        # Top targeted users
        print("[+] Top 10 Targeted Users:")
        user_stats = defaultdict(int)
        for attempt in self.failed_attempts:
            user_stats[attempt['user']] += 1

        for user, count in sorted(user_stats.items(), key=lambda x: x[1], reverse=True)[:10]:
            print(f"    {user:25s}: {count:5d} attempts")
        print()

        # Top source IPs
        print("[+] Top 10 Source IP Addresses:")
        ip_stats = defaultdict(int)
        for attempt in self.failed_attempts:
            if attempt['source'] != "Unknown":
                ip_stats[attempt['source']] += 1

        for ip, count in sorted(ip_stats.items(), key=lambda x: x[1], reverse=True)[:10]:
            print(f"    {ip:25s}: {count:5d} attempts")
        print()

        # Recent attempts (last 20)
        print("[+] Most Recent Failed Attempts (Last 20):")
        print("-" * 100)
        for attempt in self.failed_attempts[-20:]:
            self._print_attempt(attempt)
        print()

        # Suspicious activity warnings
        self._check_suspicious_activity(user_stats, ip_stats)

    def _check_suspicious_activity(self, user_stats, ip_stats):
        """Check for suspicious patterns"""
        print("[!] SUSPICIOUS ACTIVITY ALERTS:")
        alerts = []

        # Check for excessive attempts from single IP
        for ip, count in ip_stats.items():
            if count > 10:
                alerts.append(f"    - High attempt count from IP {ip}: {count} attempts (possible brute force)")

        # Check for attempts on root/admin accounts
        sensitive_users = ['root', 'admin', 'administrator']
        for user in sensitive_users:
            if user in user_stats and user_stats[user] > 0:
                alerts.append(f"    - Failed attempts on sensitive account '{user}': {user_stats[user]} attempts")

        # Check for distributed attacks (many IPs targeting same user)
        for user, count in user_stats.items():
            if count > 20:
                ips_targeting_user = set(a['source'] for a in self.failed_attempts if a['user'] == user)
                if len(ips_targeting_user) > 5:
                    alerts.append(f"    - Distributed attack pattern on user '{user}': {count} attempts from {len(ips_targeting_user)} different IPs")

        if alerts:
            for alert in alerts:
                print(alert)
        else:
            print("    - No critical suspicious patterns detected")
        print()

    def export_to_csv(self, output_file="failed_logons.csv"):
        """Export failed attempts to CSV"""
        try:
            import csv
            with open(output_file, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=['timestamp', 'type', 'user', 'source', 'raw'])
                writer.writeheader()
                writer.writerows(self.failed_attempts)
            print(f"[+] Exported {len(self.failed_attempts)} failed attempts to {output_file}")
        except Exception as e:
            print(f"[!] Error exporting to CSV: {e}")


def main():
    parser = argparse.ArgumentParser(
        description='Failed Logon Monitoring Agent - Monitor and analyze failed authentication attempts',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  sudo python3 failed_logon_agent.py                          # Analyze auth logs
  sudo python3 failed_logon_agent.py --monitor                # Monitor in real-time
  sudo python3 failed_logon_agent.py --export failed.csv      # Export to CSV
  sudo python3 failed_logon_agent.py --log /var/log/secure    # Use custom log file
        """
    )

    parser.add_argument('-l', '--log', default='/var/log/auth.log',
                        help='Path to authentication log file (default: /var/log/auth.log)')
    parser.add_argument('-m', '--monitor', action='store_true',
                        help='Monitor log file in real-time')
    parser.add_argument('-e', '--export', metavar='FILE',
                        help='Export results to CSV file')
    parser.add_argument('-q', '--quiet', action='store_true',
                        help='Suppress detailed output (useful with --export)')

    args = parser.parse_args()

    # Check if running as root
    if os.geteuid() != 0 and not args.quiet:
        print("[!] Warning: Not running as root. You may not have permission to read auth logs.")
        print("[!] Try: sudo python3 failed_logon_agent.py")
        print()

    # Create agent
    agent = FailedLogonAgent(log_file=args.log)

    # Parse logs
    agent.parse_log_file(follow=args.monitor)

    # Generate report (if not monitoring)
    if not args.monitor and not args.quiet:
        agent.generate_report()

    # Export to CSV if requested
    if args.export:
        agent.export_to_csv(args.export)


if __name__ == "__main__":
    main()
