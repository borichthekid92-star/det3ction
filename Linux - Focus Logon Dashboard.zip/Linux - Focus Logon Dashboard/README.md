# Logon F0cus Dashboard

A professional, real-time web dashboard for monitoring and analyzing failed authentication attempts on Linux systems.

## 📁 Project Structure

```
logon_focus_dashboard/
├── logon_dashboard.py          # Main Flask web application
├── failed_logon_agent.py       # Authentication log parsing agent
├── start_dashboard.sh          # Quick start script
├── generate_test_logs.py       # Test data generator
├── requirements.txt            # Python dependencies
├── templates/                  # HTML templates
│   ├── dashboard.html         # Main dashboard interface
│   └── login.html             # Login page
├── data/                      # Data files
│   └── test_auth.log          # Sample test data
└── docs/                      # Documentation
    ├── DASHBOARD_README.md    # Detailed documentation
    └── auth_reference.txt     # Authentication configuration

```

## 🚀 Quick Start

### 1. Install Dependencies

```bash
cd /root/logon_focus_dashboard
pip3 install -r requirements.txt --break-system-packages
```

### 2. Start the Dashboard

**Test Mode (with sample data):**
```bash
sudo ./start_dashboard.sh --test
```

**Production Mode (real-time monitoring):**
```bash
sudo ./start_dashboard.sh
```

### 3. Access the Dashboard

Open your browser:
```
http://45.33.99.48:5000
```

**Login Credentials:**
- Check `docs/auth_reference.txt` for authentication details
- Or view source code: `logon_dashboard.py` (lines 26-29)

## ✨ Features

- 🔐 **Secure Authentication** - Login page with session management
- 📊 **Real-time Monitoring** - Auto-refresh every 5 seconds
- 🔍 **Search Functionality** - Filter by username or IP address
- ⚠️ **Security Alerts** - Color-coded suspicious activity detection
- 📈 **Statistics Dashboard** - Total attempts, unique users/IPs
- 🎯 **Top Lists** - Most targeted users and attacking IPs
- 📝 **Recent Attempts** - Detailed timeline of failed logins
- 🎨 **Professional UI** - Modern, responsive design

## 🛠️ Configuration

### Change Authentication Credentials

Edit `logon_dashboard.py`:
```python
CREDENTIALS = {
    'username': 'your_username',
    'password': 'your_password'
}
```

### Change Port

```bash
sudo python3 logon_dashboard.py -p 8080
```

### Custom Log File

```bash
sudo python3 logon_dashboard.py -l /var/log/secure
```

## 📖 Command Line Options

```bash
python3 logon_dashboard.py --help

Options:
  -p, --port PORT           Port to run on (default: 5000)
  --host HOST              Host to bind to (default: 0.0.0.0)
  -l, --log FILE           Authentication log file path
  --no-monitor             Disable real-time monitoring
```

## 🧪 Testing

Generate sample test data:
```bash
python3 generate_test_logs.py
```

This creates `test_auth.log` with 100 sample failed login attempts.

## 🔒 Security Notes

- **Default credentials** should be changed in production
- Dashboard runs on all interfaces (0.0.0.0) by default
- Consider using `--host 127.0.0.1` for localhost-only access
- Add firewall rules to restrict access to port 5000
- Sessions persist until logout
- All API endpoints require authentication

## 📚 Documentation

Detailed documentation available in:
- `docs/DASHBOARD_README.md` - Complete feature documentation
- `docs/auth_reference.txt` - Authentication configuration guide

## 🔧 Troubleshooting

**Permission Denied:**
```bash
sudo python3 logon_dashboard.py
```

**Port Already in Use:**
```bash
sudo python3 logon_dashboard.py -p 8080
```

**No Data Showing:**
- Check log file exists: `ls -la /var/log/auth.log`
- Use correct log for your system (auth.log or secure)
- Verify there are actual failed login attempts in the log

**Firewall Blocking:**
```bash
sudo ufw allow 5000/tcp
```

## 📋 Requirements

- Python 3.x
- Flask 3.x
- Root privileges (to read authentication logs)
- Linux system with auth logs

## 🎯 Use Cases

- Security monitoring and incident response
- Intrusion detection and analysis
- Brute force attack identification
- Security auditing and compliance
- Real-time threat monitoring
- Security operations center (SOC) tool

## 📧 Support

For issues or questions, refer to the documentation in `docs/` directory.

---

**© 2025 Logon F0cus Dashboard**
Professional Failed Authentication Monitoring System
