#!/usr/bin/env python3
"""
Generate sample authentication log entries for testing the dashboard
"""

import random
from datetime import datetime, timedelta

# Sample data
USERNAMES = ['root', 'admin', 'user1', 'postgres', 'mysql', 'ubuntu', 'testuser', 'deploy', 'jenkins']
IP_ADDRESSES = [
    '192.168.1.100', '10.0.0.50', '172.16.0.10', '203.0.113.45', '198.51.100.88',
    '45.33.99.48', '104.21.45.67', '185.220.101.23', '91.203.45.12', '123.45.67.89'
]

FAILURE_PATTERNS = [
    "Failed password for {user} from {ip} port {port} ssh2",
    "Failed password for invalid user {user} from {ip} port {port} ssh2",
    "Invalid user {user} from {ip} port {port}",
    "pam_unix(sshd:auth): authentication failure; logname= uid=0 euid=0 tty=ssh ruser= rhost={ip} user={user}",
]


def generate_log_entry():
    """Generate a single random failed auth log entry"""
    now = datetime.now()
    timestamp = now.strftime("%b %d %H:%M:%S")

    user = random.choice(USERNAMES)
    ip = random.choice(IP_ADDRESSES)
    port = random.randint(30000, 60000)
    pattern = random.choice(FAILURE_PATTERNS)

    # Add more weight to certain IPs (simulate brute force)
    if random.random() < 0.3:  # 30% chance
        ip = '45.33.99.48'  # Frequent attacker

    # Add more attempts on root
    if random.random() < 0.4:  # 40% chance
        user = 'root'

    message = pattern.format(user=user, ip=ip, port=port)
    log_line = f"{timestamp} test-server sshd[{random.randint(10000, 99999)}]: {message}"

    return log_line


def main():
    print("Generating 100 sample failed authentication log entries...\n")

    entries = []
    for i in range(100):
        entry = generate_log_entry()
        entries.append(entry)
        print(entry)

    # Write to a test log file
    with open('/root/test_auth.log', 'w') as f:
        f.write('\n'.join(entries))

    print(f"\n[+] Generated 100 entries")
    print(f"[+] Saved to: /root/test_auth.log")
    print(f"\n[+] Test the dashboard with:")
    print(f"    sudo python3 /root/logon_dashboard.py -l /root/test_auth.log --no-monitor")


if __name__ == '__main__':
    main()
